$(function(){
$("#calendar").datepicker(); // plugin found from https://jqueryui.com/datepicker/
});
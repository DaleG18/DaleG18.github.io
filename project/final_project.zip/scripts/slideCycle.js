$(document).ready(function() {
    $('.slide').cycle({
    fx:      'scrollRight', 
    next:   '#right', 
    timeout:  0, 
    easing:  'easeInOutBack' 
});
});

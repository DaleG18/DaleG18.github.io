$(function(){
$("#calendar").datepicker();
});